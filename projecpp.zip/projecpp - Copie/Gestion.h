#ifndef GESTION_H
#define GESTION_H


#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMessageBox>
#include<QStandardItem>

class Livreur
{

public:
   Livreur();
    Livreur(QString,QString,QString,QString,QString,QString);

    bool ajouter();
   QSqlQueryModel * afficher(QString);
   bool supprimer(QString);
   bool modifier(QString,QString ,QString ,QString ,QString ,QString ,QString );
private:
    QString nom,prenom,adresse,email,Numcin,numtel;


};

class Livraison
{
public:
   Livraison();
    Livraison(QString,QString,QString,QString,QString,QString,QString);
    bool ajouter();
   QSqlQueryModel * afficher(QString);
   bool supprimer(QString);
   bool modifier(QString,QString ,QString ,QString ,QString ,QString ,QString ,QString);
private:
    QString nom,prenom,adresse,date,Numcin,pays,livr;

};


#endif // GESTION_H
