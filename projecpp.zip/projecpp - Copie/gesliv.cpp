#include "gesliv.h"
#include "ui_gesliv.h"
#include "mainwindow.h"
#include "geslivreurs.h"
#include "Gestion.h"
#include <QMessageBox>
#include<QStandardItem>

Gesliv::Gesliv(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Gesliv)
{
    ui->setupUi(this);
   recherche = nullptr;
   select = nullptr;
   ui->aux->setHidden(true);
   ui->help->setHidden(true);
   ui->help_2->setHidden(true);
   ui->pushButton_8->setHidden(true);
    ui->tabLiv->setModel(liv->afficher(recherche));

   ui->tabLiv->setShowGrid(true);
    ui->tabLiv->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tabLiv->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tabLiv->horizontalHeader()->setStretchLastSection(true);
    ui->tabLiv->resizeColumnsToContents();
    ui->tabLiv->setColumnWidth(5,350);
    ui->tabLiv->setColumnWidth(0,20);

    QString nomliv;
    QSqlQuery query;
    query.prepare("select * from livreur ");
    query.exec();
    while (query.next())
    {
       nomliv = query.value(1).toString() +" "+ query.value(2).toString();

        ui->liv->addItem(nomliv);


    }

}

Gesliv::~Gesliv()
{
    delete ui;

}

void  Gesliv :: updater ()
{

    ui->tabLiv->setModel(liv->afficher(recherche));
    select = nullptr;

}

void Gesliv::closepopup()
{

   ui->help_2->setHidden(true);
   delay1->stop();


}
void Gesliv::closepopup2()
{

   ui->help->setHidden(true);
  delay2->stop();

}

void Gesliv::closeWin()
{

     this->close();

        this->deleteLater();
}

void Gesliv::on_acceuilbtn_clicked()
{
    MainWindow *main;
    main = new MainWindow();
    main->showFullScreen();
    delay = new QTimer(this);
   connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
   delay->start(500);

}

void Gesliv::on_quitter_clicked()
{
    int reponse = QMessageBox::warning(this, "Quitter", "Etes-vous sûr(e) de vouloir quitter ?", QMessageBox::Yes |  QMessageBox::Cancel);



        if (reponse == QMessageBox::Yes)
        {

            close();

        }




}


void Gesliv::on_pushButton_3_clicked()
{
    geslivreurs *ges;
    ges = new geslivreurs();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}

void Gesliv::on_pushButton_4_clicked()
{

    select = nullptr;
    QString nom = ui->nom->text();
    QString prenom = ui->prenom->text();
    QString ad = ui->adresse->text();
    QString pays = ui->pays->text();
    QString cin = ui->cin->text();
    QString date = ui->dateEdit->text();
    QString liv = ui->liv->currentText();
    if(nom == nullptr || prenom == nullptr || ad == nullptr || cin == nullptr || pays == nullptr || date == nullptr || liv == nullptr)
    {
        QMessageBox::warning(nullptr, QObject::tr("Verification"),
                            QObject::tr("Verifier les champ.\n"
                                        "Click OK to try again."), QMessageBox::Ok);
    }
    else
    {
     Livraison livr(cin,nom, prenom , pays ,  ad , date ,liv);
    bool test= livr.ajouter();
    if(test)
       {
        updater();

        QMessageBox::information(nullptr, QObject::tr("Livreur ajouter"),
                    QObject::tr("Livraison ajouter Avec succes.\n"
                                "Click OK to exit."), QMessageBox::Ok);




        ui->nom->clear();
         ui->prenom->clear();
        ui->adresse->clear();
        ui->pays->clear();
        ui->cin->clear();

          ui->dateEdit->clear();


    }
    }

}

void Gesliv::on_pushButton_5_clicked()
{
    QSqlQuery query;
    query.prepare("select * from livraison where id='"+select+"'");
    query.exec();
    while (query.next())
    {

        test = query.value(0).toString();


    }
  if(select == test && test != nullptr)
    {
      int i = 0;
      QString nomliv;
      QSqlQuery query;
      query.prepare("select * from livreur ");
      query.exec();
      ui->liv->clear();
      while (query.next())
      {

          if(i == 0)
          {
            ui->liv->addItem("");
          }

              i++;
         nomliv = query.value(1).toString() +" "+ query.value(2).toString();


          ui->liv->addItem(nomliv);


      }
      i=0;

      ui->cin->setText(select);
      ui->aux->setText(select);
      query.prepare("select * from livraison where id='"+select+"'");
      query.exec();
      while (query.next())
      {

          ui->cin->setText(query.value(1).toString());
          ui->nom->setText(query.value(2).toString());
          ui->prenom->setText(query.value(3).toString());
          ui->pays->setText(query.value(4).toString());
          ui->adresse->setText(query.value(5).toString());
          ui->dateEdit->setDate(query.value(6).toDate());
          ui->liv->setItemText(0,query.value(7).toString());

      }
      ui->pushButton_8->setHidden(false);

    }
      else
    {
     ui->help_2->setHidden(true);
    ui->help->setText("Pour Modifier Une Livraison : Cliquez DEUX fois sur son ( ID ) Dans le Tableau Puis Appuyer sur Modifier");
   ui->help->setHidden(false);
   delay2 = new QTimer(this);
  connect(delay2,SIGNAL(timeout()),this,SLOT(closepopup2()));
  delay2->start(5000);
    }
}

void Gesliv::on_pushButton_6_clicked()
{
    QSqlQuery query;
    query.prepare("select * from livraison where id='"+select+"'");
    query.exec();
    while (query.next())
    {

        test = query.value(0).toString();


    }
  if(select == test  && test != nullptr)
  {
      int reponse = QMessageBox::critical(this, "Suppression", "Etes-vous sûr(e) de vouloir Supprimer Cet Livraison ?", QMessageBox::Yes |  QMessageBox::Cancel);



          if (reponse == QMessageBox::Yes)
          {
              liv->supprimer(select);
              updater();

          }

  }
    else
  {
     ui->help->setHidden(true);
    ui->help_2->setText("Pour Supprimer Une Livraison : Cliquez DEUX fois sur son ( ID ) Dans le Tableau Puis Appuyer sur Supprimer");
   ui->help_2->setHidden(false);
   delay1 = new QTimer(this);
  connect(delay1,SIGNAL(timeout()),this,SLOT(closepopup()));
  delay1->start(5000);
  }
}

void Gesliv::on_tabLiv_activated(const QModelIndex &index)
{
    select = ui->tabLiv->model()->data(index).toString();
}

void Gesliv::on_pushButton_7_clicked()
{
    recherche = ui->cherch->text();
    ui->tabLiv->setModel(liv->afficher(recherche));
}

void Gesliv::on_actualiser_clicked()
{
    ui->cherch->clear();
    recherche = nullptr;
    select = nullptr;
     ui->tabLiv->setModel(liv->afficher(recherche));

}

void Gesliv::on_pdf_clicked()
{

    QDateTime datecreation = date.currentDateTime();
    QString afficheDC = "Date de Creation PDF : " + datecreation.toString() ;

       QPdfWriter pdf("C:/Users/RH/Desktop/PdfLivraison.pdf");
       QPainter painter(&pdf);
      int i = 4000;


           painter.setPen(Qt::blue);
           painter.setFont(QFont("Arial", 30));
           painter.drawText(1100,1200,"Liste Des Livraisons");
           painter.setPen(Qt::black);
           painter.setFont(QFont("Arial", 15));
           painter.drawText(1100,2000,afficheDC);
           painter.drawRect(100,100,7300,2600);
           painter.drawPixmap(QRect(7600,70,2000,2600),QPixmap("C:/Users/RH/Desktop/projecpp/image/logopdf.png"));
           painter.drawRect(0,3000,9600,500);
           painter.setFont(QFont("Arial", 9));
           painter.drawText(200,3300,"ID");
           painter.drawText(900,3300,"NUM_CIN");
           painter.drawText(2000,3300,"NOM");
           painter.drawText(2800,3300,"PRENOM");
           painter.drawText(3800,3300,"PAYS");
           painter.drawText(5300,3300,"ADRESSE");
           painter.drawText(7200,3300,"DATE DE LIVRAISON");
           painter.drawText(8800,3300,"LIVREUR");
           QSqlQuery query;
           query.prepare("select * from livraison ");
           query.exec();
           while (query.next())
           {

               painter.drawText(200,i,query.value(0).toString());
               painter.drawText(900,i,query.value(1).toString());
               painter.drawText(2000,i,query.value(2).toString());
               painter.drawText(2800,i,query.value(3).toString());
               painter.drawText(3800,i,query.value(4).toString());
               painter.drawText(4700,i,query.value(5).toString());
               painter.drawText(7500,i,query.value(6).toString());
               painter.drawText(8800,i,query.value(7).toString());
              i = i + 500;


           }

           int reponse = QMessageBox::question(this, "Génerer PDF", "<PDF Enregistré>...Vous Voulez Affichez Le PDF ?", QMessageBox::Yes |  QMessageBox::No);



               if (reponse == QMessageBox::Yes)
               {
                   service.openUrl(QUrl("C:/Users/RH/Desktop/PdfLivraison.pdf"));
                   painter.end();
               }
               if (reponse == QMessageBox::No)
               {
                    painter.end();
               }


}

void Gesliv::on_pushButton_8_clicked()
{
    QString aux = ui->aux->text();
    QString cin = ui->cin->text();
    QString nom = ui->nom->text();
    QString prenom = ui->prenom->text();
    QString pays = ui->pays->text();
    QString ad = ui->adresse->text();
    QString date = ui->dateEdit->text();
    QString livr = ui->liv->currentText();
    if(nom == nullptr || prenom == nullptr || ad == nullptr || cin == nullptr || pays == nullptr || date == nullptr || livr == nullptr)
    {
        QMessageBox::warning(nullptr, QObject::tr("Verification"),
                            QObject::tr("Verifier les champ.\n"
                                        "Click OK to try again."), QMessageBox::Ok);
    }
    else
    {
    liv->modifier(aux,cin,nom,prenom,pays,ad,date,livr);
    updater();
    ui->pushButton_8->setHidden(true);
    QMessageBox::warning(nullptr, QObject::tr("Modification"),
                        QObject::tr("Modification fait avec succes.\n"
                                    "Click OK to continue."), QMessageBox::Ok);
    ui->nom->clear();
     ui->prenom->clear();
    ui->adresse->clear();
    ui->pays->clear();
    ui->cin->clear();

      ui->dateEdit->clear();
      ui->liv->clear();
      QString nomliv;
      QSqlQuery query;
      query.prepare("select * from livreur ");
      query.exec();
      while (query.next())
      {
         nomliv = query.value(1).toString() +" "+ query.value(2).toString();

          ui->liv->addItem(nomliv);


      }
    }
}
