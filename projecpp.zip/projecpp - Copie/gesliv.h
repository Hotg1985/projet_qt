#ifndef GESLIV_H
#define GESLIV_H

#include "Gestion.h"
#include "Connexion.h"
#include <cassert>
#include <QHeaderView>
#include <QStandardItemModel>
#include <QMainWindow>
#include <QTimer>

#include <QDateTime>
#include <QPdfWriter>
#include <QPainter>
#include <QDesktopServices>

QT_BEGIN_NAMESPACE
namespace Ui {
class Gesliv;
}
QT_END_NAMESPACE
class Gesliv : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gesliv(QWidget *parent = nullptr);
    ~Gesliv();

    QString recherche;
    QString select;
    QString test;

private slots:
   void closepopup();
   void closepopup2();
     void updater();

    void closeWin();
    void on_acceuilbtn_clicked();

    void on_quitter_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_tabLiv_activated(const QModelIndex &index);

    void on_pushButton_7_clicked();

    void on_actualiser_clicked();

    void on_pdf_clicked();

    void on_pushButton_8_clicked();

private:

     QTimer *delay;
    Ui::Gesliv *ui;
    QTimer *delay1;
    QTimer *delay2;

    Livraison *liv;

    QDesktopServices service;
    QDateTime date;
};

#endif // GESLIV_H
