

#include "Gestion.h"


Livreur::Livreur()
{

}

Livraison::Livraison()
{

}

Livreur::Livreur(QString numcin,QString numtel,QString nom , QString prenom , QString adresse , QString email)
{
this->Numcin=numcin;
   this->numtel=numtel;
    this->adresse=adresse;
    this->email=email;
this->nom=nom;
this->prenom=prenom;
}

bool Livreur::ajouter()
{
    QSqlQuery query;

    query.prepare("INSERT INTO livreur (num_cin, nom, prenom ,num_tel,adresse,email) VALUES (:a, :b, :c,:d,:e,:f)");
    query.bindValue(":a",Numcin);
    query.bindValue(":b",nom);
    query.bindValue(":c",prenom);
    query.bindValue(":d",numtel);
    query.bindValue(":e",adresse);
    query.bindValue(":f",email);
    return query.exec();
}

bool Livreur::modifier(QString aux, QString cin,QString nom,QString prenom,QString tel,QString adres ,QString email)
{
    QSqlQuery query;

    query.prepare("update livreur set num_cin = :a, nom = :b, prenom = :c,num_tel = :d,adresse = :e,email = :f where num_cin ='"+aux+"'");
    query.bindValue(":a",cin);
    query.bindValue(":b",nom);
    query.bindValue(":c",prenom);
    query.bindValue(":d",tel);
    query.bindValue(":e",adres);
    query.bindValue(":f",email);
    return query.exec();
}

QSqlQueryModel * Livreur::afficher(QString recherche)
{


    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery *query = new QSqlQuery();
if(recherche == nullptr)
{
model->setQuery("select * from livreur");
model->setHeaderData(0, Qt::Horizontal,QObject::tr("NUM_CIN"));
model->setHeaderData(1, Qt::Horizontal,QObject::tr("NOM"));
model->setHeaderData(2, Qt::Horizontal,QObject::tr("PRENOM"));
model->setHeaderData(3, Qt::Horizontal,QObject::tr("NUM_TEL"));
model->setHeaderData(4, Qt::Horizontal,QObject::tr("ADRESSE"));
model->setHeaderData(5, Qt::Horizontal,QObject::tr("EMAIL"));
}
else
{
query->prepare("select * from livreur where nom =? or prenom =? or num_cin=?");
query->addBindValue(recherche);
query->addBindValue(recherche);
query->addBindValue(recherche);
query->exec();
model->setQuery(*query);
}
return model;
}

bool Livreur::supprimer(QString aux)
{
    QSqlQuery query;
    query.prepare("delete from livreur where num_cin = :a");
    query.bindValue(":a",aux);
    return query.exec();
}

/****************livraison**********************/

Livraison::Livraison(QString numcin,QString nom,QString prenom,QString pays , QString adresse , QString date , QString livreur)
{
this->Numcin=numcin;
   this->nom=nom;
    this->adresse=adresse;
    this->pays=pays;
this->date=date;
this->livr=livreur;
this->prenom=prenom;
}

bool Livraison::ajouter()
{
    QSqlQuery query;

    query.prepare("INSERT INTO livraison (num_cin, nom, prenom ,pays,adresse,date_de_livraison,livreur) VALUES (:a, :b, :c,:d,:e,:f ,:g)");
    query.bindValue(":a",Numcin);
    query.bindValue(":b",nom);
    query.bindValue(":c",prenom);
    query.bindValue(":d",pays);
    query.bindValue(":e",adresse);
    query.bindValue(":f",date);
    query.bindValue(":g",livr);
    return query.exec();
}

bool Livraison::modifier(QString aux, QString cin,QString nom,QString prenom,QString pays,QString adres ,QString date ,QString livr)
{
    QSqlQuery query;

    query.prepare("update livraison set num_cin = :a, nom = :b, prenom = :c,pays = :d,adresse = :e,date_de_livraison = :f ,livreur = :g where id ='"+aux+"'");
    query.bindValue(":a",cin);
    query.bindValue(":b",nom);
    query.bindValue(":c",prenom);
    query.bindValue(":d",pays);
    query.bindValue(":e",adres);
    query.bindValue(":f",date);
    query.bindValue(":g",livr);
    return query.exec();
}

QSqlQueryModel * Livraison::afficher(QString recherche)
{


    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery *query = new QSqlQuery();
if(recherche == nullptr)
{
model->setQuery("select * from livraison");
model->setHeaderData(0, Qt::Horizontal,QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal,QObject::tr("NUM_CIN"));
model->setHeaderData(2, Qt::Horizontal,QObject::tr("NOM"));
model->setHeaderData(3, Qt::Horizontal,QObject::tr("PRENOM"));
model->setHeaderData(4, Qt::Horizontal,QObject::tr("PAYS"));
model->setHeaderData(5, Qt::Horizontal,QObject::tr("ADRESSE"));
model->setHeaderData(6, Qt::Horizontal,QObject::tr("DATE_DE_LIVRAISON"));
model->setHeaderData(7, Qt::Horizontal,QObject::tr("LIVREUR"));
}
else
{
query->prepare("select * from livraison where nom =? or prenom =? or num_cin=? or livreur=? or DATE_DE_LIVRAISON=? " );
query->addBindValue(recherche);
query->addBindValue(recherche);
query->addBindValue(recherche);
query->addBindValue(recherche);
query->addBindValue(recherche);
query->exec();
model->setQuery(*query);
}
return model;
}

bool Livraison::supprimer(QString aux)
{
    QSqlQuery query;
    query.prepare("delete from livraison where id = :a");
    query.bindValue(":a",aux);
    return query.exec();
}
