#include "geslivreurs.h"
#include "mainwindow.h"
#include "ui_geslivreursl.h"
#include "gesliv.h"
#include "Gestion.h"
#include"Connexion.h"
#include<QStandardItem>


geslivreurs::geslivreurs(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::geslivreurs)
{
    ui->setupUi(this);
   recherche = nullptr;
   select = nullptr;
   ui->help->setHidden(true);
   ui->help_2->setHidden(true);
   ui->pushButton_4->setHidden(true);
    ui->tablivr->setModel(liv->afficher(recherche));

    ui->tablivr->setShowGrid(true);
    ui->tablivr->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tablivr->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tablivr->horizontalHeader()->setStretchLastSection(true);
    ui->tablivr->resizeColumnsToContents();
    ui->tablivr->setColumnWidth(4,350);
    ui->tablivr->setColumnWidth(0,100);




}

geslivreurs::~geslivreurs()
{

    delete ui;

}



void  geslivreurs :: updater ()
{

    ui->tablivr->setModel(liv->afficher(recherche));
    select = nullptr;

}
void geslivreurs::closeWin()
{


 this->close();

    this->deleteLater();

}
void geslivreurs::closepopup()
{

   ui->help_2->setHidden(true);
   delay1->stop();


}
void geslivreurs::closepopup2()
{

   ui->help->setHidden(true);
  delay2->stop();

}
void geslivreurs::on_pushButton_2_clicked()
{
    Gesliv *ges;
    ges = new Gesliv();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}



void geslivreurs::on_acceuilbtn_clicked()
{
    MainWindow *main;
    main = new MainWindow();
    main->showFullScreen();
    delay = new QTimer(this);
   connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
   delay->start(500);

}

void geslivreurs::on_quitter_clicked()
{
    int reponse = QMessageBox::warning(this, "Quitter", "Etes-vous sûr(e) de vouloir quitter ?", QMessageBox::Yes |  QMessageBox::Cancel);



        if (reponse == QMessageBox::Yes)
        {

            close();


        }


}

void geslivreurs::on_pushButton_5_clicked()
{

    select = nullptr;
    QString nom = ui->nom->text();
    QString prenom = ui->prenom->text();
    QString ad = ui->adres->text();
    QString email = ui->email->text();
    QString cin = ui->numcin->text();
    QString tel = ui->ntel->text();
    if(nom == nullptr || prenom == nullptr || ad == nullptr || cin == nullptr || tel == nullptr)
    {
        QMessageBox::warning(nullptr, QObject::tr("Verification"),
                            QObject::tr("Verifier les champ.\n"
                                        "Click OK to try again."), QMessageBox::Ok);
    }
    else
    {
    Livreur liv(cin,tel,nom , prenom ,  ad ,  email);
    bool test= liv.ajouter();
    if(test)
       { QMessageBox::information(nullptr, QObject::tr("Livreur ajouter"),
                    QObject::tr("Livreur ajouter Avec succes.\n"
                                "Click OK to exit."), QMessageBox::Ok);




        ui->nom->clear();
         ui->prenom->clear();
        ui->adres->clear();
        ui->email->clear();
        ui->numcin->clear();
         ui->ntel->clear();
        updater();


    }
    }
}

void geslivreurs::on_pushButton_8_clicked()
{

    QSqlQuery query;
    query.prepare("select * from livreur where num_cin='"+select+"'");
    query.exec();
    while (query.next())
    {

        test = query.value(0).toString();


    }
  if(select == test && test != nullptr)
    {

        QSqlQuery query;
        query.prepare("select * from livreur where num_cin='"+select+"'");
        query.exec();
        while (query.next())
        {
            ui->aux->setText(query.value(0).toString());
            ui->numcin->setText(query.value(0).toString());
            ui->nom->setText(query.value(1).toString());
            ui->prenom->setText(query.value(2).toString());
            ui->ntel->setText(query.value(3).toString());
            ui->adres->setText(query.value(4).toString());
            ui->email->setText(query.value(5).toString());


        }
        ui->pushButton_4->setHidden(false);
  }
    else
  {
   ui->help_2->setHidden(true);
  ui->help->setText("Pour Modifier Un Livreur : Cliquez DEUX fois sur son ( NUM_CIN ) Dans le Tableau Puis Appuyer sur Modifier");
 ui->help->setHidden(false);
 delay2 = new QTimer(this);
connect(delay2,SIGNAL(timeout()),this,SLOT(closepopup2()));
delay2->start(5000);
  }





}
void geslivreurs::on_pushButton_4_clicked()
{
    QString aux = ui->aux->text();
    QString cin = ui->numcin->text();
    QString nom = ui->nom->text();
    QString prenom = ui->prenom->text();
    QString tel = ui->ntel->text();
    QString ad = ui->adres->text();
    QString email = ui->email->text();
    if(nom == nullptr || prenom == nullptr || ad == nullptr || cin == nullptr || tel == nullptr)
    {
        QMessageBox::warning(nullptr, QObject::tr("Verification"),
                            QObject::tr("Verifier les champ.\n"
                                        "Click OK to try again."), QMessageBox::Ok);
    }
    else
    {
        liv->modifier(aux,cin,nom,prenom,tel,ad,email);
   updater();
   QMessageBox::information(nullptr, QObject::tr("Modification"),
                       QObject::tr("Modification terminé avec succes.\n"
                                   "Click OK to continue."), QMessageBox::Ok);
   ui->pushButton_4->setHidden(true);

   ui->nom->clear();
    ui->prenom->clear();
   ui->adres->clear();
   ui->email->clear();
   ui->numcin->clear();
    ui->ntel->clear();

    }
}

void geslivreurs::on_cherchlivr_clicked()
{
    recherche = ui->cherchslide->text();
    ui->tablivr->setModel(liv->afficher(recherche));


}

void geslivreurs::on_actualiser_clicked()
{
    ui->cherchslide->clear();
    recherche = nullptr;
    select = nullptr;
     ui->tablivr->setModel(liv->afficher(recherche));
}

void geslivreurs::on_tablivr_activated(const QModelIndex &index)
{


    select = ui->tablivr->model()->data(index).toString();



}

void geslivreurs::on_pushButton_6_clicked()
{
    QSqlQuery query;
    query.prepare("select * from livreur where num_cin='"+select+"'");
    query.exec();
    while (query.next())
    {

        test = query.value(0).toString();


    }
  if(select == test  && test != nullptr)
  {
      int reponse = QMessageBox::critical(this, "Suppression", "Etes-vous sûr(e) de vouloir Supprimer Ce Livreur ?", QMessageBox::Yes |  QMessageBox::Cancel);



          if (reponse == QMessageBox::Yes)
          {
              liv->supprimer(select);
              updater();

          }

  }
    else
  {
     ui->help->setHidden(true);
    ui->help_2->setText("Pour Supprimer Un Livreur : Cliquez DEUX fois sur son ( NUM_CIN ) Dans le Tableau Puis Appuyer sur Supprimer");
   ui->help_2->setHidden(false);
   delay1 = new QTimer(this);
  connect(delay1,SIGNAL(timeout()),this,SLOT(closepopup()));
  delay1->start(5000);
  }
}

void geslivreurs::on_pdf_clicked()
{
    QDateTime datecreation = date.currentDateTime();
    QString afficheDC = "Date de Creation PDF : " + datecreation.toString() ;

       QPdfWriter pdf("C:/Users/RH/Desktop/PdfLivreur.pdf");
       QPainter painter(&pdf);
      int i = 4000;


           painter.setPen(Qt::blue);
           painter.setFont(QFont("Arial", 30));
           painter.drawText(1100,1200,"Liste Des Livreurs");
           painter.setPen(Qt::black);
           painter.setFont(QFont("Arial", 15));
           painter.drawText(1100,2000,afficheDC);
           painter.drawRect(100,100,7300,2600);
           painter.drawPixmap(QRect(7600,70,2000,2600),QPixmap("C:/Users/RH/Desktop/projecpp/image/logopdf.png"));
           painter.drawRect(0,3000,9600,500);
           painter.setFont(QFont("Arial", 9));
           painter.drawText(200,3300,"NUM_CIN");
           painter.drawText(1300,3300,"NOM");
           painter.drawText(2100,3300,"PRENOM");
           painter.drawText(3200,3300,"NUM_TEL");
           painter.drawText(5300,3300,"ADRESSE");
           painter.drawText(8000,3300,"EMAIL");

           QSqlQuery query;
           query.prepare("select * from livreur ");
           query.exec();
           while (query.next())
           {

               painter.drawText(200,i,query.value(0).toString());
               painter.drawText(1300,i,query.value(1).toString());
               painter.drawText(2200,i,query.value(2).toString());
               painter.drawText(3200,i,query.value(3).toString());
               painter.drawText(4500,i,query.value(4).toString());
               painter.drawText(7700,i,query.value(5).toString());

              i = i + 500;


           }
           int reponse = QMessageBox::question(this, "Génerer PDF", "<PDF Enregistré>...Vous Voulez Affichez Le PDF ?", QMessageBox::Yes |  QMessageBox::No);



               if (reponse == QMessageBox::Yes)
               {
                   service.openUrl(QUrl("C:/Users/RH/Desktop/PdfLivreur.pdf"));
                   painter.end();
               }
               if (reponse == QMessageBox::No)
               {
                    painter.end();
               }



}


