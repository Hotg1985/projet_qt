#ifndef GESLIVREURS_H
#define GESLIVREURS_H
#include "Gestion.h"
#include "Connexion.h"
#include <QMainWindow>
#include <QTimer>
#include <cassert>

#include <QHeaderView>
#include <QStandardItemModel>
#include <QDateTime>
#include <QPdfWriter>
#include <QPainter>
#include <QDesktopServices>

namespace Ui {
class geslivreurs;
}

class geslivreurs : public QMainWindow
{
    Q_OBJECT

public:



    explicit geslivreurs(QWidget *parent = nullptr);
    ~geslivreurs();
     QString recherche;
     QString select;
     QString test;

private slots:
    void closepopup();
    void closepopup2();
      void updater();
    void on_pushButton_2_clicked();
    void closeWin();
     void on_quitter_clicked();
    void on_acceuilbtn_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_8_clicked();

    void on_cherchlivr_clicked();

    void on_actualiser_clicked();

    void on_tablivr_activated(const QModelIndex &index);

    void on_pushButton_6_clicked();

    void on_pdf_clicked();

    void on_pushButton_4_clicked();

private:
    QTimer *delay;
    QTimer *delay1;
    QTimer *delay2;
    Ui::geslivreurs *ui;
    Livreur *liv;
    QDesktopServices service;
    QDateTime date;


};

#endif // GESLIVREURS_H
