#include "Connexion.h"

Connexion::Connexion()
{

}

bool Connexion::ouvrirconnexiontest()
{
   bool test=false;
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("projet");
db.setUserName("rami");//inserer nom de l'utilisateur
db.setPassword("esprit20");//inserer mot de passe de cet utilisateur

if (db.open())
{test=true;}
    return  test;

}

void Connexion::ouvrirconnexion()
{
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("projet");
db.setUserName("rami");//inserer nom de l'utilisateur
db.setPassword("esprit20");//inserer mot de passe de cet utilisateur
db.open();

}


void Connexion::fermerconnexion()
{
    db.close();
}
